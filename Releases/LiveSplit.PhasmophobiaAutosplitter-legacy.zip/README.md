# LiveSplit.PhasmophobiaAutosplitter
This LiveSplit Auto Splitter provides automatic start, split, reset, and optional load removal for Phasmophobia by tracking in-game memory values.

## Features (Tied to SRC Ruling)
- Automatic run start on contract initialization
- Automatic split when leaving at contract finish from truck context
- Optional reset on contract leave
- Automatic reset when the game process closes
- Restart loop handling while timer is running (auto reset + restart when a new run start is detected before first split)
- Optional multi-contract mode with load removal support for full-game routes

## Supported Game Versions
- Current Steam build (Unity 2022.3.40f1 / IL2CPP)

Other game versions may work as well or partially.

## How to use
1. Open LiveSplit.
2. Right-click -> Edit Splits.
3. Set *Game Name* to Phasmophobia.
4. Activate the Auto Splitter.
5. Open Settings and configure start/split/reset/options.

# Settings

### Start
- Start on Contract Initialization - Starts the timer when the player and truck are completely finished initializing and the player is allowed to move.
- Backup: Start on First Movement is always on internally and triggers if initialization start is missed.

### Split
- Split on Contract Finish - Splits when a contract-finish loading transition is triggered when you are inside the truck.
- Backup: CCTV truck-presence fallback is used when strict truck-exit trigger data is missing.

### Reset
- Allow Resetting on Contract Leave, Game Close and New Run Start - Enables all auto-reset behavior:
resets when a loading transition is triggered when you are not inside the truck,
resets on game close, and auto reset+start when a new run start is detected while the timer is running.
(If this is off, all auto-reset behavior is disabled.)

## Options
- Multi-Contract and Load Removal (IGT/LRT)
  - Multi-Contract: lets you chain contracts/maps in one attempt.
  - Load Removal: while using Game Time in LiveSplit, loading-screen frames are removed after first split. Real Time is unchanged.
- Warn on Reset if Gold
  - Shows LiveSplit's reset warning prompt when the current attempt already contains at least one gold split.

# Known Issues
- Leaving truck then re-entering can treat a normal leave loading transition as a split.
- Multiplayer may be unreliable.
- Game updates can break memory signatures until the autosplitter is updated.
- Restarting the game may rarely break the autosplitter.
If this happens, restart LiveSplit or reload the component.

# Contributing
Bug reports and code improvements are welcome.
